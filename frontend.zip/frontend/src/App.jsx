import {
BrowserRouter,
Routes,
Route
} from "react-router-dom";

import StudentLogin from "./pages/StudentLogin";
import StudentDashboard from "./pages/StudentDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import InstitutionPortal from "./pages/InstitutionPortal";
import CertificateView from "./pages/CertificateView";
import VerificationPage from "./pages/VerificationPage";

function App(){

return(

<BrowserRouter>

<Routes>

<Route
path="/student-login"
element={<StudentLogin/>}
/>

<Route
path="/student"
element={<StudentDashboard/>}
/>

<Route
path="/admin"
element={<AdminDashboard/>}
/>

<Route
path="/institution"
element={<InstitutionPortal/>}
/>

<Route
path="/verify/:certificateID"
element={<VerificationPage/>}
/>

<Route
path="/certificate/:certificateID"
element={<CertificateView/>}
/>

</Routes>

</BrowserRouter>

);

}

export default App;
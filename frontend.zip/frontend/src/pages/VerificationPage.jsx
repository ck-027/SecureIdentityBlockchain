import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ethers } from "ethers";
import CertificateABI from "../contracts/CertificateVerificationABI.json";

function VerificationPage(){

    const { certificateID } = useParams();

    const [certificate, setCertificate] =
        useState(null);

    const [loading, setLoading] =
        useState(true);

    const [notFound, setNotFound] =
        useState(false);


const contractAddress =
    "0x9219c0Bb6Fe04DCD570443AD13d49DEB3DA2681b";


    async function loadCertificate(){

        try{

            const provider =
                new ethers.BrowserProvider(
                    window.ethereum
                );

            const contract =
                new ethers.Contract(

                    contractAddress,

                    CertificateABI,

                    provider

                );

            const data =
                await contract.verifyCertificate(
                    certificateID
                );


            const studentName =
                data[0];

            const qualification =
                data[1];

            const institution =
                data[2];


            if(

                studentName === "" &&
                qualification === "" &&
                institution === ""

            ){

                setNotFound(true);

                return;

            }


            setCertificate({

                studentName:data[0],

                qualification:data[1],

                institution:data[2],

                certificateHash:data[3],

                verified:data[4]

            });

        }
        catch(error){

            console.error(error);

            setNotFound(true);

        }
        finally{

            setLoading(false);

        }

    }


    useEffect(()=>{

        loadCertificate();

    },[]);



    if(loading){

        return(

            <div
                style={{
                    minHeight:"100vh",
                    display:"flex",
                    justifyContent:"center",
                    alignItems:"center",
                    background:"#f5f7fb"
                }}
            >

                <h2>
                    Loading verification...
                </h2>

            </div>

        );

    }



    if(notFound){

        return(

            <div
                style={{
                    minHeight:"100vh",
                    background:"#f5f7fb",
                    padding:"40px"
                }}
            >

                <div
                    style={{
                        maxWidth:"700px",
                        margin:"0 auto",
                        background:"white",
                        padding:"30px",
                        borderRadius:"12px",
                        boxShadow:
                            "0 2px 10px rgba(0,0,0,0.1)"
                    }}
                >

                    <h1>
                        Certificate Verification
                    </h1>

                    <hr/>

                    <h2
                        style={{
                            color:"#d97706"
                        }}
                    >
                        ⚠ CERTIFICATE NOT FOUND
                    </h2>

                    <p>

                        The certificate ID:

                        <b>
                            {" "}
                            {certificateID}
                        </b>

                        {" "}
                        does not exist on the blockchain.

                    </p>

                </div>

            </div>

        );

    }



    return(

        <div
            style={{
                minHeight:"100vh",
                background:"#f5f7fb",
                padding:"40px"
            }}
        >

            <div
                style={{
                    maxWidth:"700px",
                    margin:"0 auto",
                    background:"white",
                    padding:"30px",
                    borderRadius:"12px",
                    boxShadow:
                        "0 2px 10px rgba(0,0,0,0.1)"
                }}
            >

                <h1>
                    Certificate Verification
                </h1>

                <hr/>

                {

                    certificate.verified

                    ?

                    <h2
                        style={{
                            color:"green"
                        }}
                    >
                        ✓ CERTIFICATE VERIFIED
                    </h2>

                    :

                    <h2
                        style={{
                            color:"red"
                        }}
                    >
                        ✕ CERTIFICATE REVOKED
                    </h2>

                }

                <br/>

                <p>
                    <b>Student:</b>
                    {" "}
                    {certificate.studentName}
                </p>

                <p>
                    <b>Qualification:</b>
                    {" "}
                    {certificate.qualification}
                </p>

                <p>
                    <b>Institution:</b>
                    {" "}
                    {certificate.institution}
                </p>

                <p>
                    <b>Certificate ID:</b>
                    {" "}
                    {certificateID}
                </p>

                <p>
                    <b>Blockchain Status:</b>
                    {" "}

                    {

                        certificate.verified

                        ?

                        "VALID"

                        :

                        "REVOKED"

                    }

                </p>

                <br/>

                {
                    certificate.verified
                    ?

                    <Link
                        to={`/certificate/${certificateID}`}
                    >

                        <button>
                            View Full Certificate
                        </button>

                    </Link>

                    :

                    <div>

                        <p
                            style={{
                                color:"red",
                                fontWeight:"bold"
                            }}
                        >
                            This certificate has been revoked
                            by the issuing institution.
                        </p>

                    </div>
                }

            </div>

        </div>

    );

}

export default VerificationPage;
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ethers } from "ethers";

import CertificateABI from "../contracts/CertificateVerificationABI.json";

function StudentDashboard() {

    const navigate =
        useNavigate();


    const [certificateID, setCertificateID] =
        useState("");

    const [certificate, setCertificate] =
        useState(null);

    const [loading, setLoading] =
        useState(true);


    /*
     * NEW DEPLOYED CONTRACT
     */
const contractAddress =
    "0x9219c0Bb6Fe04DCD570443AD13d49DEB3DA2681b";

    /*
     * Convert blockchain timestamp
     * into a readable date.
     */
    function formatDate(timestamp) {

        if (!timestamp) {
            return "N/A";
        }

        return new Date(
            Number(timestamp) * 1000
        ).toLocaleDateString();

    }


    /*
     * Load certificate from blockchain.
     */
    async function loadCertificate(id) {

        try {

            if (!window.ethereum) {

                throw new Error(
                    "MetaMask is not installed."
                );

            }


            const provider =
                new ethers.BrowserProvider(
                    window.ethereum
                );


            const contract =
                new ethers.Contract(

                    contractAddress,

                    CertificateABI,

                    provider

                );


            const data =
                await contract.verifyCertificate(
                    id
                );


            /*
             * IMPORTANT:
             *
             * data[0] = studentName
             * data[1] = qualification
             * data[2] = institution
             * data[3] = certificateHash
             * data[4] = issueDate
             * data[5] = blockchainTimestamp
             * data[6] = verified
             */

            setCertificate({

                studentName:
                    data[0],

                qualification:
                    data[1],

                institution:
                    data[2],

                certificateHash:
                    data[3],

                issueDate:
                    data[4],

                blockchainTimestamp:
                    data[5],

                verified:
                    data[6]

            });

        }

        catch (error) {

            console.error(
                "Certificate loading error:",
                error
            );

            setCertificate(null);

        }

        finally {

            setLoading(false);

        }

    }


    /*
     * Check student login.
     */
    useEffect(() => {

        const loggedIn =
            sessionStorage.getItem(
                "studentLoggedIn"
            );


        const storedCertificateID =
            sessionStorage.getItem(
                "studentCertificateID"
            );


        if (
            loggedIn !== "true" ||
            !storedCertificateID
        ) {

            sessionStorage.removeItem(
                "studentLoggedIn"
            );

            sessionStorage.removeItem(
                "studentCertificateID"
            );


            navigate(
                "/student-login",
                {
                    replace: true
                }
            );


            return;

        }


        setCertificateID(
            storedCertificateID
        );


        loadCertificate(
            storedCertificateID
        );

    }, [navigate]);


    /*
     * Open certificate.
     */
    function openCertificate() {

        navigate(
            `/certificate/${certificateID}`
        );

    }


    /*
     * Logout.
     */
    function logout() {

        sessionStorage.removeItem(
            "studentLoggedIn"
        );


        sessionStorage.removeItem(
            "studentCertificateID"
        );


        setCertificate(null);


        navigate(
            "/student-login",
            {
                replace: true
            }
        );

    }


    /*
     * Loading screen.
     */
    if (loading) {

        return (

            <div
                style={{
                    minHeight: "100vh",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    background: "#f5f7fb"
                }}
            >

                <h2>
                    Loading certificate...
                </h2>

            </div>

        );

    }


    /*
     * Certificate not found.
     */
    if (!certificate) {

        return (

            <div
                style={{
                    minHeight: "100vh",
                    padding: "40px",
                    background: "#f5f7fb"
                }}
            >

                <h2>
                    Certificate could not be loaded.
                </h2>


                <p>
                    Certificate ID:
                    {" "}
                    <b>
                        {certificateID}
                    </b>
                </p>


                <p>
                    Please make sure the certificate
                    exists on the current blockchain
                    network.
                </p>


                <button
                    onClick={logout}
                >

                    Return to Login

                </button>

            </div>

        );

    }


    return (

        <div
            style={{
                minHeight: "100vh",
                background: "#f5f7fb",
                padding: "40px"
            }}
        >

            <div
                style={{
                    background: "white",
                    maxWidth: "700px",
                    margin: "0 auto",
                    padding: "30px",
                    borderRadius: "12px",
                    boxShadow:
                        "0 2px 10px rgba(0,0,0,0.1)"
                }}
            >

                <h1>
                    Student Dashboard
                </h1>


                <p>

                    Welcome,

                    {" "}

                    <b>
                        {certificate.studentName}
                    </b>

                </p>


                <hr />


                <h3>
                    Certificate Information
                </h3>


                <p>

                    <b>
                        Certificate ID:
                    </b>

                    {" "}

                    {certificateID}

                </p>


                <p>

                    <b>
                        Student:
                    </b>

                    {" "}

                    {certificate.studentName}

                </p>


                <p>

                    <b>
                        Qualification:
                    </b>

                    {" "}

                    {certificate.qualification}

                </p>


                <p>

                    <b>
                        Institution:
                    </b>

                    {" "}

                    {certificate.institution}

                </p>


                <p>

                    <b>
                        Official Issue / Graduation Date:
                    </b>

                    {" "}

                    {formatDate(
                        certificate.issueDate
                    )}

                </p>


                <p>

                    <b>
                        Blockchain Recorded:
                    </b>

                    {" "}

                    {formatDate(
                        certificate.blockchainTimestamp
                    )}

                </p>


                <p>

                    <b>
                        Certificate Hash:
                    </b>

                    <br />

                    <small>
                        {certificate.certificateHash}
                    </small>

                </p>


                <p>

                    <b>
                        Status:
                    </b>

                    {" "}


                    {

                        certificate.verified

                        ?

                        (

                            <span
                                style={{
                                    color: "green",
                                    fontWeight: "bold"
                                }}
                            >

                                ✓ Blockchain Verified

                            </span>

                        )

                        :

                        (

                            <span
                                style={{
                                    color: "red",
                                    fontWeight: "bold"
                                }}
                            >

                                ✕ Certificate Revoked

                            </span>

                        )

                    }

                </p>


                <br />


                {

                    certificate.verified

                    ?

                    (

                        <button

                            onClick={
                                openCertificate
                            }

                            style={{
                                padding: "10px 20px",
                                marginRight: "10px",
                                cursor: "pointer"
                            }}

                        >

                            View Certificate

                        </button>

                    )

                    :

                    (

                        <p
                            style={{
                                color: "red",
                                fontWeight: "bold"
                            }}
                        >

                            This certificate has been revoked
                            by the institution and is no longer
                            considered valid.

                        </p>

                    )

                }


                <button

                    onClick={
                        logout
                    }

                    style={{
                        padding: "10px 20px",
                        cursor: "pointer"
                    }}

                >

                    Logout

                </button>


            </div>

        </div>

    );

}


export default StudentDashboard;
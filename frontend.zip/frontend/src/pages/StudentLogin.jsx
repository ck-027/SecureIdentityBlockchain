import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ethers } from "ethers";

import CertificateABI from "../contracts/CertificateVerificationABI.json";


function StudentLogin() {

    const [certificateID, setCertificateID] =
        useState("");

    const [password, setPassword] =
        useState("");

    const [error, setError] =
        useState("");

    const [loading, setLoading] =
        useState(false);


    const navigate =
        useNavigate();


const contractAddress =
    "0x9219c0Bb6Fe04DCD570443AD13d49DEB3DA2681b";

    async function login() {

        setError("");


        const cleanCertificateID =
            certificateID.trim();


        const cleanPassword =
            password.trim();


        if (
            !cleanCertificateID ||
            !cleanPassword
        ) {

            setError(
                "Please enter your Certificate ID and password."
            );

            return;

        }


        try {

            setLoading(true);


            /*
             * Connect to the blockchain.
             */
            if (!window.ethereum) {

                setError(
                    "MetaMask is required to log in."
                );

                return;

            }


            const provider =
                new ethers.BrowserProvider(
                    window.ethereum
                );


            /*
             * Create read-only contract connection.
             */
            const contract =
                new ethers.Contract(

                    contractAddress,

                    CertificateABI,

                    provider

                );


            /*
             * First check that the certificate exists
             * and is still valid.
             */
            const certificate =
                await contract.verifyCertificate(
                    cleanCertificateID
                );


            /*
             * The contract returns empty strings
             * when the certificate ID does not exist.
             */
            if (!certificate[0]) {

                setError(
                    "Certificate ID not found."
                );

                return;

            }


            /*
             * Check whether the certificate
             * has been revoked.
             */
            if (!certificate[6]) {

                setError(
                    "This certificate has been revoked and cannot be used to log in."
                );

                return;

            }


            /*
             * Hash the password entered by
             * the student.
             *
             * This produces the same type of
             * hash that was stored when the
             * certificate was issued.
             */
            const passwordHash =
                ethers.keccak256(

                    ethers.toUtf8Bytes(
                        cleanPassword
                    )

                );


            /*
             * Ask the smart contract to verify
             * the password hash.
             */
            const passwordCorrect =
                await contract.verifyStudentPassword(

                    cleanCertificateID,

                    passwordHash

                );


            if (!passwordCorrect) {

                setError(
                    "Incorrect password."
                );

                return;

            }


            /*
             * Login successful.
             */
            sessionStorage.setItem(

                "studentCertificateID",

                cleanCertificateID

            );


            sessionStorage.setItem(

                "studentLoggedIn",

                "true"

            );


            navigate(
                "/student"
            );

        }

        catch (error) {

            console.error(
                "Student login error:",
                error
            );


            setError(

                error?.reason ||

                error?.shortMessage ||

                error?.message ||

                "Unable to verify your credentials."

            );

        }

        finally {

            setLoading(false);

        }

    }


    return (

        <div

            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                minHeight: "100vh",
                background: "#f5f7fb"
            }}

        >

            <div

                style={{
                    background: "white",
                    padding: "40px",
                    borderRadius: "12px",
                    width: "400px",
                    boxShadow:
                        "0 2px 10px rgba(0,0,0,0.1)"
                }}

            >

                <h1>
                    verify.edu.pg
                </h1>


                <h2>
                    Student Login
                </h2>


                <p>
                    Enter your certificate credentials
                    to access your student portal.
                </p>


                <br />


                <label>
                    Certificate ID
                </label>


                <br />


                <input

                    value={certificateID}

                    onChange={(e) =>
                        setCertificateID(
                            e.target.value
                        )
                    }

                    placeholder="e.g. CERT-123456"

                    style={{
                        width: "100%",
                        padding: "10px",
                        marginTop: "5px",
                        marginBottom: "15px",
                        boxSizing: "border-box"
                    }}

                />


                <label>
                    Password
                </label>


                <br />


                <input

                    type="password"

                    value={password}

                    onChange={(e) =>
                        setPassword(
                            e.target.value
                        )
                    }

                    placeholder="Enter your password"

                    style={{
                        width: "100%",
                        padding: "10px",
                        marginTop: "5px",
                        marginBottom: "15px",
                        boxSizing: "border-box"
                    }}

                />


                {

                    error && (

                        <p

                            style={{
                                color: "red",
                                fontWeight: "bold"
                            }}

                        >

                            {error}

                        </p>

                    )

                }


                <button

                    onClick={login}

                    disabled={loading}

                    style={{
                        width: "100%",
                        padding: "12px",
                        cursor:
                            loading
                            ? "not-allowed"
                            : "pointer"
                    }}

                >

                    {

                        loading

                        ? "Verifying..."

                        : "Login"

                    }

                </button>


            </div>

        </div>

    );

}


export default StudentLogin;
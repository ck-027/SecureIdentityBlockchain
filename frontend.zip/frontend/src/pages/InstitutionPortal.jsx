import { useState, useEffect } from "react";
import { ethers } from "ethers";
import CertificateABI from "../contracts/CertificateVerificationABI.json";

function InstitutionPortal() {
    const [studentName, setStudentName] = useState("");
    const [qualification, setQualification] = useState("");
    const [issueDate, setIssueDate] = useState("");

    const [certificates, setCertificates] = useState([]);

    const [selectedCertificate, setSelectedCertificate] =
        useState(null);

    const [showPassword, setShowPassword] =
        useState(false);

    const [searchTerm, setSearchTerm] =
        useState("");

    /*
     * CSV BULK ISSUING
     */
    const [csvRows, setCsvRows] = useState([]);
    const [csvFileName, setCsvFileName] = useState("");
    const [csvError, setCsvError] = useState("");
    const [bulkIssuing, setBulkIssuing] = useState(false);
    const [bulkProgress, setBulkProgress] = useState(0);
    const [bulkResults, setBulkResults] = useState([]);

    const institution =
        "PNG University of Technology";

    /*
     * Deployed CertificateVerification contract.
     */
    const contractAddress =
        "0x9219c0Bb6Fe04DCD570443AD13d49DEB3DA2681b";

    /*
     * Get a signer-connected contract.
     */
    async function getContract() {
        if (!window.ethereum) {
            throw new Error(
                "MetaMask is not installed."
            );
        }

        const provider =
            new ethers.BrowserProvider(
                window.ethereum
            );

        const signer =
            await provider.getSigner();

        return new ethers.Contract(
            contractAddress,
            CertificateABI,
            signer
        );
    }

    /*
     * Generate an 8-character student password.
     */
    function generatePassword() {
        const chars =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        let password = "";

        for (let i = 0; i < 8; i++) {
            password +=
                chars.charAt(
                    Math.floor(
                        Math.random() *
                        chars.length
                    )
                );
        }

        return password;
    }

    /*
     * Convert blockchain timestamp
     * into a readable date.
     */
    function formatDate(timestamp) {
        if (!timestamp) {
            return "N/A";
        }

        return new Date(
            Number(timestamp) * 1000
        ).toLocaleDateString();
    }

    /*
     * Create certificate hash.
     */
    function createCertificateHash(
        student,
        qualificationName,
        certificateIssueDate
    ) {
        return ethers.keccak256(
            ethers.toUtf8Bytes(
                student +
                qualificationName +
                institution +
                certificateIssueDate
            )
        );
    }

    /*
     * Store student credentials locally.
     */
    function storeCredentials(
        certificateID,
        password,
        student,
        qualificationName
    ) {
        localStorage.setItem(
            certificateID,
            JSON.stringify({
                password: password,
                studentName: student,
                qualification: qualificationName
            })
        );
    }

    /*
     * Generate certificate ID.
     *
     * IMPORTANT:
     * This uses exactly the same format
     * as manual certificate issuing.
     *
     * Example:
     *
     * CERT-1723456789012
     *
     * Both manual and CSV certificates
     * now use this same format.
     */
    function generateCertificateID() {
        return "CERT-" + Date.now();
    }

    /*
     * ISSUE ONE CERTIFICATE
     */
    async function issueCertificate() {
        try {
            if (
                !studentName.trim() ||
                !qualification.trim() ||
                !issueDate
            ) {
                alert(
                    "Please enter the student name, qualification and issue date."
                );

                return;
            }

            const contract =
                await getContract();

            /*
             * Generate certificate ID.
             */
            const certificateID =
                generateCertificateID();

            /*
             * Convert issue date to
             * Unix timestamp.
             */
            const issueDateTimestamp =
                Math.floor(
                    new Date(
                        issueDate + "T00:00:00"
                    ).getTime() / 1000
                );

            /*
             * Generate certificate hash.
             */
            const certificateHash =
                createCertificateHash(
                    studentName.trim(),
                    qualification.trim(),
                    issueDate
                );

            /*
             * Generate student password.
             */
            const studentPassword =
                generatePassword();

            /*
             * Hash student password.
             */
            const passwordHash =
                ethers.keccak256(
                    ethers.toUtf8Bytes(
                        studentPassword
                    )
                );

            /*
             * Issue certificate on blockchain.
             */
            const transaction =
                await contract.issueCertificate(
                    certificateID,
                    studentName.trim(),
                    qualification.trim(),
                    institution,
                    certificateHash,
                    issueDateTimestamp,
                    passwordHash
                );

            /*
             * Wait for blockchain confirmation.
             */
            await transaction.wait();

            /*
             * Store credentials locally.
             */
            storeCredentials(
                certificateID,
                studentPassword,
                studentName.trim(),
                qualification.trim()
            );

            /*
             * Show credentials to institution.
             */
            alert(
                "Certificate Issued Successfully!\n\n" +
                "Certificate ID: " +
                certificateID +
                "\n\n" +
                "Official Issue / Graduation Date: " +
                issueDate +
                "\n\n" +
                "Student Password: " +
                studentPassword
            );

            /*
             * Clear form.
             */
            setStudentName("");
            setQualification("");
            setIssueDate("");

            /*
             * Reload certificates.
             */
            await loadCertificates();
        }
        catch (error) {
            console.error(
                "Error issuing certificate:",
                error
            );

            alert(
                "Error issuing certificate.\n\n" +
                (
                    error?.reason ||
                    error?.shortMessage ||
                    error?.message ||
                    "Unknown blockchain error."
                )
            );
        }
    }

    /*
     * REVOKE CERTIFICATE
     */
    async function revokeCertificate(
        certificateID
    ) {
        try {
            const contract =
                await getContract();

            const transaction =
                await contract.revokeCertificate(
                    certificateID
                );

            await transaction.wait();

            alert(
                "Certificate revoked successfully."
            );

            await loadCertificates();
        }
        catch (error) {
            console.error(error);

            alert(
                "Failed to revoke certificate.\n\n" +
                (
                    error?.reason ||
                    error?.shortMessage ||
                    error?.message ||
                    "Unknown blockchain error."
                )
            );
        }
    }

    /*
     * CONFIRM REVOCATION
     */
    function confirmRevocation(
        certificateID
    ) {
        const confirmed =
            window.confirm(
                `Are you sure you want to revoke ${certificateID}?\n\nThis action will invalidate the certificate.`
            );

        if (confirmed) {
            revokeCertificate(
                certificateID
            );
        }
    }

    /*
     * LOAD ALL CERTIFICATES
     */
    async function loadCertificates() {
        try {
            if (!window.ethereum) {
                return;
            }

            const provider =
                new ethers.BrowserProvider(
                    window.ethereum
                );

            const contract =
                new ethers.Contract(
                    contractAddress,
                    CertificateABI,
                    provider
                );

            /*
             * Get all certificate IDs.
             */
            const ids =
                await contract.getAllCertificateIDs();

            const certificateList = [];

            /*
             * Retrieve each certificate.
             */
            for (const id of ids) {
                const data =
                    await contract.verifyCertificate(
                        id
                    );

                certificateList.push({
                    id: id,
                    student: data[0],
                    qualification: data[1],
                    institution: data[2],
                    hash: data[3],
                    issueDate: data[4],
                    blockchainTimestamp: data[5],
                    verified: data[6]
                });
            }

            setCertificates(
                certificateList
            );
        }
        catch (error) {
            console.error(
                "Loading certificates failed:",
                error
            );
        }
    }

    /*
     * OPEN STUDENT CREDENTIALS
     */
    function openCredentials(
        certificate
    ) {
        const storedData =
            localStorage.getItem(
                certificate.id
            );

        let password = null;

        if (storedData) {
            try {
                const credentials =
                    JSON.parse(
                        storedData
                    );

                password =
                    credentials.password;
            }
            catch (error) {
                /*
                 * Supports older format.
                 */
                password =
                    storedData;
            }
        }

        setSelectedCertificate({
            ...certificate,
            password: password
        });

        setShowPassword(false);
    }

    /*
     * CLOSE CREDENTIAL MODAL
     */
    function closeCredentials() {
        setSelectedCertificate(null);
        setShowPassword(false);
    }

    /*
     * =========================================
     * CSV BULK CERTIFICATE ISSUING
     * =========================================
     */

    /*
     * Download CSV template.
     */
    function downloadCSVTemplate() {
        const csv =
            "studentName,qualification,issueDate\n" +
            "John Doe,Bachelor of Information Technology,2026-08-15\n" +
            "Jane Smith,Diploma in Business,2026-08-20";

        const blob =
            new Blob(
                [csv],
                {
                    type: "text/csv;charset=utf-8;"
                }
            );

        const url =
            URL.createObjectURL(blob);

        const link =
            document.createElement("a");

        link.href = url;
        link.download =
            "certificate_upload_template.csv";

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);

        URL.revokeObjectURL(url);
    }

    /*
     * Parse one CSV line.
     *
     * Supports quoted values containing
     * commas.
     */
    function parseCSVLine(line) {
        const values = [];

        let current = "";
        let insideQuotes = false;

        for (
            let i = 0;
            i < line.length;
            i++
        ) {
            const character =
                line[i];

            if (character === '"') {
                if (
                    insideQuotes &&
                    line[i + 1] === '"'
                ) {
                    current += '"';
                    i++;
                }
                else {
                    insideQuotes =
                        !insideQuotes;
                }
            }
            else if (
                character === "," &&
                !insideQuotes
            ) {
                values.push(
                    current.trim()
                );

                current = "";
            }
            else {
                current += character;
            }
        }

        values.push(
            current.trim()
        );

        return values;
    }

    /*
     * Handle CSV upload.
     */
    function handleCSVUpload(event) {
        const file =
            event.target.files?.[0];

        setCsvError("");
        setCsvRows([]);
        setBulkResults([]);
        setBulkProgress(0);

        if (!file) {
            return;
        }

        setCsvFileName(
            file.name
        );

        if (
            !file.name
                .toLowerCase()
                .endsWith(".csv")
        ) {
            setCsvError(
                "Please upload a CSV file."
            );

            return;
        }

        const reader =
            new FileReader();

        reader.onload =
            function (event) {
                try {
                    const text =
                        event.target.result
                            .replace(
                                /^\uFEFF/,
                                ""
                            );

                    const lines =
                        text
                            .split(/\r?\n/)
                            .filter(
                                line =>
                                    line.trim() !== ""
                            );

                    if (lines.length < 2) {
                        setCsvError(
                            "The CSV file must contain a header row and at least one student."
                        );

                        return;
                    }

                    const headers =
                        parseCSVLine(
                            lines[0]
                        ).map(
                            header =>
                                header
                                    .trim()
                                    .toLowerCase()
                        );

                    const studentNameIndex =
                        headers.indexOf(
                            "studentname"
                        );

                    const qualificationIndex =
                        headers.indexOf(
                            "qualification"
                        );

                    const issueDateIndex =
                        headers.indexOf(
                            "issuedate"
                        );

                    if (
                        studentNameIndex === -1 ||
                        qualificationIndex === -1 ||
                        issueDateIndex === -1
                    ) {
                        setCsvError(
                            "Invalid CSV headers. The file must contain: studentName, qualification, issueDate"
                        );

                        return;
                    }

                    const parsedRows = [];

                    for (
                        let i = 1;
                        i < lines.length;
                        i++
                    ) {
                        const values =
                            parseCSVLine(
                                lines[i]
                            );

                        const student =
                            values[
                                studentNameIndex
                            ] || "";

                        const qualificationName =
                            values[
                                qualificationIndex
                            ] || "";

                        const date =
                            values[
                                issueDateIndex
                            ] || "";

                        const errors = [];

                        if (!student.trim()) {
                            errors.push(
                                "Student name is missing"
                            );
                        }

                        if (
                            !qualificationName.trim()
                        ) {
                            errors.push(
                                "Qualification is missing"
                            );
                        }

                        if (!date.trim()) {
                            errors.push(
                                "Issue date is missing"
                            );
                        }
                        else if (
                            !/^\d{4}-\d{2}-\d{2}$/.test(
                                date.trim()
                            )
                        ) {
                            errors.push(
                                "Issue date must use YYYY-MM-DD"
                            );
                        }

                        parsedRows.push({
                            rowNumber: i + 1,
                            studentName:
                                student.trim(),
                            qualification:
                                qualificationName.trim(),
                            issueDate:
                                date.trim(),
                            errors: errors
                        });
                    }

                    setCsvRows(
                        parsedRows
                    );
                }
                catch (error) {
                    console.error(
                        "CSV parsing error:",
                        error
                    );

                    setCsvError(
                        "Unable to read the CSV file."
                    );
                }
            };

        reader.onerror =
            function () {
                setCsvError(
                    "Unable to read the selected file."
                );
            };

        reader.readAsText(file);
    }

    /*
     * Clear uploaded CSV.
     */
    function clearCSV() {
        setCsvRows([]);
        setCsvFileName("");
        setCsvError("");
        setBulkResults([]);
        setBulkProgress(0);

        const fileInput =
            document.getElementById(
                "certificate-csv-upload"
            );

        if (fileInput) {
            fileInput.value = "";
        }
    }

    /*
     * Escape CSV values when creating
     * the credentials download file.
     */
    function escapeCSVValue(value) {
        const stringValue =
            String(
                value ?? ""
            );

        if (
            stringValue.includes(",") ||
            stringValue.includes('"') ||
            stringValue.includes("\n")
        ) {
            return (
                '"' +
                stringValue.replace(
                    /"/g,
                    '""'
                ) +
                '"'
            );
        }

        return stringValue;
    }

    /*
     * Download generated credentials.
     */
    function downloadCredentialsCSV() {
        const successfulResults =
            bulkResults.filter(
                result =>
                    result.success
            );

        if (
            successfulResults.length === 0
        ) {
            alert(
                "There are no successful certificates to download."
            );

            return;
        }

        const header =
            "Certificate ID,Student Name,Qualification,Issue Date,Student Password";

        const rows =
            successfulResults.map(
                result =>
                    [
                        result.certificateID,
                        result.studentName,
                        result.qualification,
                        result.issueDate,
                        result.password
                    ]
                        .map(
                            escapeCSVValue
                        )
                        .join(",")
            );

        const csv =
            [header, ...rows]
                .join("\n");

        const blob =
            new Blob(
                [csv],
                {
                    type: "text/csv;charset=utf-8;"
                }
            );

        const url =
            URL.createObjectURL(blob);

        const link =
            document.createElement("a");

        link.href = url;

        link.download =
            "student_certificate_credentials.csv";

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);

        URL.revokeObjectURL(url);
    }

    /*
     * BULK ISSUE CERTIFICATES
     */
    async function issueBulkCertificates() {
        if (
            csvRows.length === 0
        ) {
            alert(
                "Please upload a CSV file first."
            );

            return;
        }

        const invalidRows =
            csvRows.filter(
                row =>
                    row.errors.length > 0
            );

        if (
            invalidRows.length > 0
        ) {
            alert(
                "Please fix the invalid rows in the CSV before issuing certificates."
            );

            return;
        }

        const confirmed =
            window.confirm(
                `You are about to issue ${csvRows.length} certificate(s).\n\nEach certificate will require a blockchain transaction.\n\nContinue?`
            );

        if (!confirmed) {
            return;
        }

        try {
            setBulkIssuing(true);
            setBulkProgress(0);
            setBulkResults([]);

            const contract =
                await getContract();

            const results = [];

            for (
                let i = 0;
                i < csvRows.length;
                i++
            ) {
                const row =
                    csvRows[i];

                try {
                    /*
                     * Generate certificate ID.
                     *
                     * IMPORTANT:
                     * This now uses the exact same
                     * format as manual issuing.
                     */
                    const certificateID =
                        generateCertificateID();

                    /*
                     * Convert date to Unix timestamp.
                     */
                    const issueDateTimestamp =
                        Math.floor(
                            new Date(
                                row.issueDate +
                                "T00:00:00"
                            ).getTime() /
                            1000
                        );

                    if (
                        Number.isNaN(
                            issueDateTimestamp
                        )
                    ) {
                        throw new Error(
                            "Invalid issue date."
                        );
                    }

                    /*
                     * Generate certificate hash.
                     */
                    const certificateHash =
                        createCertificateHash(
                            row.studentName,
                            row.qualification,
                            row.issueDate
                        );

                    /*
                     * Generate student password.
                     */
                    const studentPassword =
                        generatePassword();

                    /*
                     * Hash password.
                     */
                    const passwordHash =
                        ethers.keccak256(
                            ethers.toUtf8Bytes(
                                studentPassword
                            )
                        );

                    /*
                     * Issue certificate on blockchain.
                     */
                    const transaction =
                        await contract.issueCertificate(
                            certificateID,
                            row.studentName,
                            row.qualification,
                            institution,
                            certificateHash,
                            issueDateTimestamp,
                            passwordHash
                        );

                    /*
                     * Wait for confirmation.
                     */
                    await transaction.wait();

                    /*
                     * Store credentials locally.
                     */
                    storeCredentials(
                        certificateID,
                        studentPassword,
                        row.studentName,
                        row.qualification
                    );

                    results.push({
                        rowNumber:
                            row.rowNumber,
                        success: true,
                        certificateID:
                            certificateID,
                        studentName:
                            row.studentName,
                        qualification:
                            row.qualification,
                        issueDate:
                            row.issueDate,
                        password:
                            studentPassword,
                        transactionHash:
                            transaction.hash
                    });
                }
                catch (error) {
                    console.error(
                        `Bulk issuing failed for row ${row.rowNumber}:`,
                        error
                    );

                    results.push({
                        rowNumber:
                            row.rowNumber,
                        success: false,
                        studentName:
                            row.studentName,
                        qualification:
                            row.qualification,
                        issueDate:
                            row.issueDate,
                        error:
                            error?.reason ||
                            error?.shortMessage ||
                            error?.message ||
                            "Unknown blockchain error."
                    });
                }

                /*
                 * Update progress.
                 */
                setBulkProgress(
                    Math.round(
                        ((i + 1) /
                            csvRows.length) *
                        100
                    )
                );

                /*
                 * Update results after each row
                 * so the user can see progress.
                 */
                setBulkResults(
                    [...results]
                );
            }

            /*
             * Reload certificates from blockchain.
             */
            await loadCertificates();

            const successful =
                results.filter(
                    result =>
                        result.success
                ).length;

            const failed =
                results.filter(
                    result =>
                        !result.success
                ).length;

            alert(
                "Bulk certificate issuing completed.\n\n" +
                "Successful: " +
                successful +
                "\n" +
                "Failed: " +
                failed
            );
        }
        catch (error) {
            console.error(
                "Bulk issuing error:",
                error
            );

            alert(
                "Bulk certificate issuing failed.\n\n" +
                (
                    error?.reason ||
                    error?.shortMessage ||
                    error?.message ||
                    "Unknown blockchain error."
                )
            );
        }
        finally {
            setBulkIssuing(false);
        }
    }

    /*
     * SEARCH FILTER
     */
    const filteredCertificates =
        certificates.filter(
            (certificate) => {
                const search =
                    searchTerm
                        .trim()
                        .toLowerCase();

                if (!search) {
                    return true;
                }

                const certificateID =
                    String(
                        certificate.id
                    ).toLowerCase();

                const student =
                    String(
                        certificate.student
                    ).toLowerCase();

                const qualificationName =
                    String(
                        certificate.qualification
                    ).toLowerCase();

                const institutionName =
                    String(
                        certificate.institution
                    ).toLowerCase();

                const status =
                    certificate.verified
                        ? "valid"
                        : "revoked";

                return (
                    certificateID.includes(
                        search
                    ) ||
                    student.includes(
                        search
                    ) ||
                    qualificationName.includes(
                        search
                    ) ||
                    institutionName.includes(
                        search
                    ) ||
                    status.includes(
                        search
                    )
                );
            }
        );

    /*
     * LOAD CERTIFICATES WHEN PAGE OPENS
     */
    useEffect(() => {
        if (window.ethereum) {
            loadCertificates();
        }
    }, []);

    return (
        <div
            style={{
                padding: "30px",
                background: "#f5f7fb",
                minHeight: "100vh"
            }}
        >
            <h1>
                verify.edu.pg
            </h1>

            <h2>
                Institution Portal
            </h2>

            <h3>
                {institution}
            </h3>

            <hr />

            {/* =========================
                ISSUE SINGLE CERTIFICATE
            ========================== */}

            <h2>
                Issue New Certificate
            </h2>

            <label>
                Student Name:
            </label>

            <br />

            <input
                value={studentName}
                onChange={
                    (e) =>
                        setStudentName(
                            e.target.value
                        )
                }
                placeholder="Enter student name"
            />

            <br />
            <br />

            <label>
                Qualification:
            </label>

            <br />

            <input
                value={qualification}
                onChange={
                    (e) =>
                        setQualification(
                            e.target.value
                        )
                }
                placeholder="Enter qualification"
            />

            <br />
            <br />

            <label>
                Official Issue / Graduation Date:
            </label>

            <br />

            <input
                type="date"
                value={issueDate}
                onChange={
                    (e) =>
                        setIssueDate(
                            e.target.value
                        )
                }
            />

            <br />
            <br />

            <button
                onClick={
                    issueCertificate
                }
            >
                Issue Certificate
            </button>

            <hr />

            {/* =========================
                BULK CSV ISSUING
            ========================== */}

            <h2>
                Bulk Certificate Issuing
            </h2>

            <p>
                Upload a CSV file to issue
                multiple certificates at once.
            </p>

            <div
                style={{
                    background: "white",
                    padding: "20px",
                    borderRadius: "10px",
                    marginBottom: "20px",
                    boxShadow:
                        "0 2px 8px rgba(0,0,0,0.08)"
                }}
            >
                <h3>
                    Step 1: Download CSV Template
                </h3>

                <p>
                    Use the template to ensure
                    your CSV has the correct
                    columns.
                </p>

                <button
                    onClick={
                        downloadCSVTemplate
                    }
                    disabled={bulkIssuing}
                >
                    Download CSV Template
                </button>

                <hr />

                <h3>
                    Step 2: Upload Student CSV
                </h3>

                <p>
                    Required columns:
                    <br />
                    <b>
                        studentName, qualification, issueDate
                    </b>
                </p>

                <input
                    id="certificate-csv-upload"
                    type="file"
                    accept=".csv,text/csv"
                    onChange={
                        handleCSVUpload
                    }
                    disabled={bulkIssuing}
                />

                {
                    csvFileName && (
                        <p>
                            Selected file:
                            {" "}
                            <b>
                                {csvFileName}
                            </b>
                        </p>
                    )
                }

                {
                    csvError && (
                        <p
                            style={{
                                color: "red",
                                fontWeight: "bold"
                            }}
                        >
                            {csvError}
                        </p>
                    )
                }

                {
                    csvRows.length > 0 && (
                        <>
                            <hr />

                            <h3>
                                CSV Preview
                            </h3>

                            <p>
                                Students loaded:
                                {" "}
                                <b>
                                    {csvRows.length}
                                </b>
                            </p>

                            <div
                                style={{
                                    overflowX:
                                        "auto"
                                }}
                            >
                                <table
                                    border="1"
                                    cellPadding="8"
                                    style={{
                                        borderCollapse:
                                            "collapse",
                                        minWidth:
                                            "800px"
                                    }}
                                >
                                    <thead>
                                        <tr>
                                            <th>
                                                Row
                                            </th>

                                            <th>
                                                Student
                                            </th>

                                            <th>
                                                Qualification
                                            </th>

                                            <th>
                                                Issue Date
                                            </th>

                                            <th>
                                                Validation
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {
                                            csvRows.map(
                                                row => (
                                                    <tr
                                                        key={
                                                            row.rowNumber
                                                        }
                                                    >
                                                        <td>
                                                            {
                                                                row.rowNumber
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                row.studentName
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                row.qualification
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                row.issueDate
                                                            }
                                                        </td>

                                                        <td
                                                            style={{
                                                                color:
                                                                    row.errors.length >
                                                                    0
                                                                        ? "red"
                                                                        : "green"
                                                            }}
                                                        >
                                                            {
                                                                row.errors.length >
                                                                0
                                                                    ? row.errors.join(
                                                                          ", "
                                                                      )
                                                                    : "✓ Valid"
                                                            }
                                                        </td>
                                                    </tr>
                                                )
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>

                            <br />

                            {
                                !bulkIssuing && (
                                    <>
                                        <button
                                            onClick={
                                                issueBulkCertificates
                                            }
                                            disabled={
                                                csvRows.some(
                                                    row =>
                                                        row.errors.length >
                                                        0
                                                )
                                            }
                                            style={{
                                                padding:
                                                    "12px 20px",
                                                fontWeight:
                                                    "bold"
                                            }}
                                        >
                                            Issue All Certificates
                                        </button>

                                        {" "}

                                        <button
                                            onClick={
                                                clearCSV
                                            }
                                        >
                                            Clear CSV
                                        </button>
                                    </>
                                )
                            }

                            {
                                bulkIssuing && (
                                    <div
                                        style={{
                                            marginTop:
                                                "20px"
                                        }}
                                    >
                                        <p>
                                            Issuing certificates...
                                        </p>

                                        <div
                                            style={{
                                                width:
                                                    "100%",
                                                maxWidth:
                                                    "600px",
                                                height:
                                                    "25px",
                                                background:
                                                    "#ddd",
                                                borderRadius:
                                                    "5px",
                                                overflow:
                                                    "hidden"
                                            }}
                                        >
                                            <div
                                                style={{
                                                    width:
                                                        `${bulkProgress}%`,
                                                    height:
                                                        "100%",
                                                    background:
                                                        "#4caf50",
                                                    transition:
                                                        "width 0.3s"
                                                }}
                                            />
                                        </div>

                                        <p>
                                            {
                                                bulkProgress
                                            }%
                                        </p>
                                    </div>
                                )
                            }
                        </>
                    )
                }

                {
                    bulkResults.length > 0 && (
                        <div
                            style={{
                                marginTop:
                                    "25px"
                            }}
                        >
                            <hr />

                            <h3>
                                Bulk Issuing Results
                            </h3>

                            <p>
                                Successful:
                                {" "}
                                <b>
                                    {
                                        bulkResults.filter(
                                            result =>
                                                result.success
                                        ).length
                                    }
                                </b>

                                {" | "}

                                Failed:
                                {" "}
                                <b>
                                    {
                                        bulkResults.filter(
                                            result =>
                                                !result.success
                                        ).length
                                    }
                                </b>
                            </p>

                            <div
                                style={{
                                    overflowX:
                                        "auto"
                                }}
                            >
                                <table
                                    border="1"
                                    cellPadding="8"
                                    style={{
                                        borderCollapse:
                                            "collapse",
                                        minWidth:
                                            "900px"
                                    }}
                                >
                                    <thead>
                                        <tr>
                                            <th>
                                                Row
                                            </th>

                                            <th>
                                                Student
                                            </th>

                                            <th>
                                                Certificate ID
                                            </th>

                                            <th>
                                                Status
                                            </th>

                                            <th>
                                                Details
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {
                                            bulkResults.map(
                                                result => (
                                                    <tr
                                                        key={
                                                            result.rowNumber
                                                        }
                                                    >
                                                        <td>
                                                            {
                                                                result.rowNumber
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                result.studentName
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                result.certificateID ||
                                                                "—"
                                                            }
                                                        </td>

                                                        <td
                                                            style={{
                                                                color:
                                                                    result.success
                                                                        ? "green"
                                                                        : "red",
                                                                fontWeight:
                                                                    "bold"
                                                            }}
                                                        >
                                                            {
                                                                result.success
                                                                    ? "✓ Issued"
                                                                    : "✕ Failed"
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                result.success
                                                                    ? "Blockchain transaction confirmed."
                                                                    : result.error
                                                            }
                                                        </td>
                                                    </tr>
                                                )
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>

                            {
                                bulkResults.some(
                                    result =>
                                        result.success
                                ) && (
                                    <>
                                        <br />

                                        <button
                                            onClick={
                                                downloadCredentialsCSV
                                            }
                                        >
                                            Download Student Credentials CSV
                                        </button>

                                        <p
                                            style={{
                                                fontSize:
                                                    "14px",
                                                color:
                                                    "#555"
                                            }}
                                        >
                                            Keep this file
                                            secure. It
                                            contains the
                                            generated
                                            student
                                            passwords.
                                        </p>
                                    </>
                                )
                            }
                        </div>
                    )
                }
            </div>

            <hr />

            {/* =========================
                ISSUED CERTIFICATES
            ========================== */}

            <h2>
                Issued Certificates
            </h2>

            {/* =========================
                SEARCH
            ========================== */}

            <div
                style={{
                    background: "white",
                    padding: "20px",
                    borderRadius: "10px",
                    marginBottom: "20px",
                    boxShadow:
                        "0 2px 8px rgba(0,0,0,0.08)"
                }}
            >
                <h3>
                    Search Certificates
                </h3>

                <input
                    type="text"
                    value={searchTerm}
                    onChange={
                        (e) =>
                            setSearchTerm(
                                e.target.value
                            )
                    }
                    placeholder={
                        "Search by Certificate ID, student name, qualification or status..."
                    }
                    style={{
                        width: "500px",
                        maxWidth: "90%",
                        padding: "12px",
                        fontSize: "15px",
                        border:
                            "1px solid #ccc",
                        borderRadius: "6px"
                    }}
                />

                <button
                    onClick={() =>
                        setSearchTerm("")
                    }
                    style={{
                        marginLeft: "10px",
                        padding:
                            "11px 16px"
                    }}
                >
                    Clear Search
                </button>

                <p>
                    Showing{" "}
                    <b>
                        {
                            filteredCertificates.length
                        }
                    </b>
                    {" "}of{" "}
                    <b>
                        {
                            certificates.length
                        }
                    </b>
                    {" "}
                    certificates
                </p>
            </div>

            {/* =========================
                CERTIFICATE TABLE
            ========================== */}

            <div
                style={{
                    overflowX: "auto"
                }}
            >
                <table
                    border="1"
                    cellPadding="10"
                    style={{
                        background: "white",
                        borderCollapse:
                            "collapse",
                        minWidth: "1100px"
                    }}
                >
                    <thead>
                        <tr>
                            <th>
                                Certificate ID
                            </th>

                            <th>
                                Student
                            </th>

                            <th>
                                Qualification
                            </th>

                            <th>
                                Official Issue Date
                            </th>

                            <th>
                                Blockchain Recorded
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Certificate
                            </th>

                            <th>
                                Credentials
                            </th>

                            <th>
                                Action
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        {
                            filteredCertificates.length === 0
                                ?
                                (
                                    <tr>
                                        <td
                                            colSpan="9"
                                            style={{
                                                textAlign:
                                                    "center",
                                                padding:
                                                    "25px"
                                            }}
                                        >
                                            No certificates
                                            match your search.
                                        </td>
                                    </tr>
                                )
                                :
                                filteredCertificates.map(
                                    (cert) => (
                                        <tr
                                            key={
                                                cert.id
                                            }
                                        >
                                            <td>
                                                {
                                                    cert.id
                                                }
                                            </td>

                                            <td>
                                                {
                                                    cert.student
                                                }
                                            </td>

                                            <td>
                                                {
                                                    cert.qualification
                                                }
                                            </td>

                                            <td>
                                                {
                                                    formatDate(
                                                        cert.issueDate
                                                    )
                                                }
                                            </td>

                                            <td>
                                                {
                                                    formatDate(
                                                        cert.blockchainTimestamp
                                                    )
                                                }
                                            </td>

                                            <td>
                                                {
                                                    cert.verified
                                                        ? "✓ Valid"
                                                        : "✕ Revoked"
                                                }
                                            </td>

                                            <td>
                                                <a
                                                    href={
                                                        `/certificate/${cert.id}`
                                                    }
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                >
                                                    <button>
                                                        View Certificate
                                                    </button>
                                                </a>
                                            </td>

                                            <td>
                                                <button
                                                    onClick={() =>
                                                        openCredentials(
                                                            cert
                                                        )
                                                    }
                                                >
                                                    Student Credentials
                                                </button>
                                            </td>

                                            <td>
                                                {
                                                    cert.verified
                                                        ?
                                                        (
                                                            <button
                                                                onClick={() =>
                                                                    confirmRevocation(
                                                                        cert.id
                                                                    )
                                                                }
                                                            >
                                                                Revoke
                                                            </button>
                                                        )
                                                        :
                                                        "N/A"
                                                }
                                            </td>
                                        </tr>
                                    )
                                )
                        }
                    </tbody>
                </table>
            </div>

            {/* =========================
                STUDENT CREDENTIAL MODAL
            ========================== */}

            {
                selectedCertificate && (
                    <div
                        style={{
                            position: "fixed",
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            background:
                                "rgba(0,0,0,0.5)",
                            display: "flex",
                            justifyContent:
                                "center",
                            alignItems:
                                "center",
                            zIndex: 1000
                        }}
                    >
                        <div
                            style={{
                                background:
                                    "white",
                                padding:
                                    "30px",
                                borderRadius:
                                    "12px",
                                width:
                                    "400px",
                                maxWidth:
                                    "90%",
                                boxShadow:
                                    "0 5px 20px rgba(0,0,0,0.2)"
                            }}
                        >
                            <h2>
                                Student Credentials
                            </h2>

                            <hr />

                            <p>
                                <b>
                                    Student:
                                </b>
                                {" "}
                                {
                                    selectedCertificate.student
                                }
                            </p>

                            <p>
                                <b>
                                    Certificate ID:
                                </b>
                                {" "}
                                {
                                    selectedCertificate.id
                                }
                            </p>

                            <p>
                                <b>
                                    Qualification:
                                </b>
                                {" "}
                                {
                                    selectedCertificate.qualification
                                }
                            </p>

                            <p>
                                <b>
                                    Official Issue Date:
                                </b>
                                {" "}
                                {
                                    formatDate(
                                        selectedCertificate.issueDate
                                    )
                                }
                            </p>

                            <p>
                                <b>
                                    Blockchain Recorded:
                                </b>
                                {" "}
                                {
                                    formatDate(
                                        selectedCertificate.blockchainTimestamp
                                    )
                                }
                            </p>

                            <p>
                                <b>
                                    Student Password:
                                </b>

                                <br />

                                {
                                    selectedCertificate.password
                                        ?
                                        showPassword
                                            ?
                                            (
                                                <span
                                                    style={{
                                                        fontWeight:
                                                            "bold",
                                                        fontSize:
                                                            "18px"
                                                    }}
                                                >
                                                    {
                                                        selectedCertificate.password
                                                    }
                                                </span>
                                            )
                                            :
                                            "••••••••"
                                        :
                                        "Credential not available on this browser."
                                }
                            </p>

                            {
                                selectedCertificate.password && (
                                    <button
                                        onClick={() =>
                                            setShowPassword(
                                                !showPassword
                                            )
                                        }
                                    >
                                        {
                                            showPassword
                                                ? "Hide Password"
                                                : "Show Password"
                                        }
                                    </button>
                                )
                            }

                            <br />
                            <br />

                            <button
                                onClick={
                                    closeCredentials
                                }
                            >
                                Close
                            </button>
                        </div>
                    </div>
                )
            }
        </div>
    );
}

export default InstitutionPortal;